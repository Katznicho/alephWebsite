<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<!-- loading in JQuery locally if CDN failed -->

{{-- use asset --}}
<script src="{{ asset('template/js/jquery.min.js') }}"></script>

<!-- Owl Carousel script -->
{{-- <script src="js/plugins/owl.carousel.min.js"></script> --}}
{{-- use asset --}}
<script src="{{ asset('template/js/plugins/owl.carousel.min.js') }}"></script>
<!-- Main (custom) script -->
{{-- <script src="dist/js/main.min.js"></script> --}}
{{-- use asset --}}
<script src="{{ asset('template/dist/js/main.min.js') }}"></script>