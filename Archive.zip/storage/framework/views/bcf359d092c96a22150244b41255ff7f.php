<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<!-- loading in JQuery locally if CDN failed -->


<script src="<?php echo e(asset('template/js/jquery.min.js')); ?>"></script>

<!-- Owl Carousel script -->


<script src="<?php echo e(asset('template/js/plugins/owl.carousel.min.js')); ?>"></script>
<!-- Main (custom) script -->


<script src="<?php echo e(asset('template/dist/js/main.min.js')); ?>"></script><?php /**PATH /Users/katendenicholas/Desktop/laravel/aleph/resources/views/components/scripts.blade.php ENDPATH**/ ?>